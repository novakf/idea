export default abstract class CypressUtils {
    static fixIfWindowsFilePath(absoluteFilePath: string): string;
}
